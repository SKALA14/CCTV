<template>
  <div class="dashboard-root">
    <div class="ambient-bg"></div>
    <div class="ambient-radial"></div>

    <header class="dashboard-header">
      <div class="header-left">
        <div class="logo-group">
          <div class="logo-icon"><i class="ri-shield-cross-line"></i></div>
          <span class="logo-text">SIREN</span>
        </div>
        <span class="status-pill">
          <span class="status-dot" :class="{ active: activeCount > 0 }"></span>
          <span class="status-text">{{ activeCount }} / 4 채널 활성</span>
        </span>
      </div>
      <div class="header-center">{{ clock }}</div>
      <div class="header-right">
        <button class="header-btn" @click="openConsole">
          <i class="ri-settings-3-line"></i><span class="btn-label">콘솔</span>
        </button>
        <button class="header-btn" :class="{ active: panelOpen }" @click="panelOpen = !panelOpen">
          <i class="ri-notification-3-line"></i><span class="btn-label">알림</span>
          <span v-if="historyCount > 0" class="notif-badge">{{ historyCount }}</span>
        </button>
      </div>
    </header>

    <div class="main-body">
      <div class="channel-grid">
        <div v-for="slotIndex in [0,1,2,3]" :key="slotIndex" class="slot-wrapper">
          <div v-if="slots[slotIndex]" class="channel-card" @mouseenter="hoveredSlot = slotIndex" @mouseleave="hoveredSlot = -1">
            <div class="video-area">
              <img :src="slots[slotIndex].ingestion_url || slots[slotIndex].url || ''" :alt="slots[slotIndex].name" class="video-img" @error="imageErrors[slotIndex] = true" />
              <div v-if="imageErrors[slotIndex]" class="video-fallback">
                <div class="fallback-icon"><i class="ri-video-off-line"></i></div>
                <p class="fallback-name">{{ slots[slotIndex].name }}</p>
                <p class="fallback-code">cam{{ slotIndex }}</p>
              </div>
              <div class="overlay-top"></div>
              <div class="live-badge"><span class="live-dot"></span><span class="live-text">LIVE</span></div>
              <div v-if="slots[slotIndex].resolution" class="res-badge"><span>{{ slots[slotIndex].resolution }} @{{ slots[slotIndex].fps }}fps</span></div>
              <div v-if="slots[slotIndex].lastEvent" class="ts-badge"><span>{{ slots[slotIndex].lastEvent }}</span></div>
              <div v-if="canEdit && hoveredSlot === slotIndex" class="action-buttons">
                <button class="action-btn" @click.stop="openEditModal(slots[slotIndex])"><i class="ri-edit-line"></i></button>
                <button class="action-btn delete" @click.stop="handleRemove(slotIndex)"><i class="ri-delete-bin-line"></i></button>
              </div>
              <div class="overlay-bottom"></div>
              <div class="channel-info">
                <div>
                  <h3 class="info-name">{{ slots[slotIndex].name }}</h3>
                  <p class="info-meta">{{ slots[slotIndex].zone || '구역 없음' }} · {{ slots[slotIndex].sourceType === 'webcam' ? '웹캠' : '소스 URL' }}</p>
                </div>
                <div class="status-chip"><span class="chip-dot"></span><span class="chip-text">정상</span></div>
              </div>
            </div>
          </div>
          <div v-else class="empty-slot" @click="canEdit && openAddModal(slotIndex)">
            <div class="empty-icon"><i class="ri-add-line"></i></div>
            <p class="empty-title">{{ canEdit ? '채널 추가' : '채널 없음' }}</p>
            <p class="empty-desc">{{ canEdit ? '클릭하여 채널을 등록하세요' : '관리자에게 문의하세요' }}</p>
          </div>
        </div>
      </div>

      <div v-if="panelOpen" class="event-panel">
        <div class="panel-header">
          <div class="panel-title-group">
            <div class="panel-icon"><i class="ri-notification-3-line"></i></div>
            <h3 class="panel-title">알림 내역</h3>
            <span v-if="unreadCount > 0" class="panel-count">{{ unreadCount }}</span>
          </div>
          <button class="panel-close" @click="panelOpen = false"><i class="ri-close-line"></i></button>
        </div>
        <div class="panel-filters">
          <button v-for="tab in filterTabs" :key="tab.key" class="filter-tab" :class="{ active: filter === tab.key }" @click="filter = tab.key">
            {{ tab.label }}<span class="filter-count" :class="{ active: filter === tab.key }">{{ tab.count }}</span>
          </button>
        </div>
        <div class="panel-list">
          <div v-if="filteredEvents.length === 0" class="panel-empty">
            <div class="empty-icon-box"><i class="ri-check-line"></i></div>
            <p class="empty-title">모든 알림을 확인했습니다</p>
            <p class="empty-desc">새로운 알림이 발생하면 여기에 표시됩니다</p>
          </div>
          <div v-else class="events-list">
            <div v-for="event in filteredEvents" :key="event.id" class="event-item" :class="{ unread: !event.read, [event.severity]: true }">
              <div class="event-dot" :class="event.severity"></div>
              <div class="event-body">
                <div class="event-header"><p class="event-channel">{{ event.channel }}</p><span class="event-time">{{ event.timestamp }}</span></div>
                <p class="event-message" :class="event.severity">{{ event.message }}</p>
              </div>
            </div>
          </div>
        </div>
        <div class="panel-footer"><p>{{ events.length }}개의 알림 중 {{ unreadCount }}개 미확인</p></div>
      </div>
    </div>

    <div v-if="showModal" class="modal-overlay" @click.self="closeModal">
      <div class="modal-card">
        <div class="modal-head">
          <div>
            <h3 class="modal-title">{{ editingChannel ? `슬롯 ${activeSlot}에 채널 수정` : `슬롯 ${activeSlot}에 채널 등록` }}</h3>
            <p class="modal-cam-id">camera_id: cam{{ activeSlot }}</p>
          </div>
          <button class="modal-close" @click="closeModal"><i class="ri-close-line"></i></button>
        </div>

        <div class="modal-body">
          <div v-if="error" class="form-error"><i class="ri-error-warning-line"></i><p>{{ error }}</p></div>

          <div class="form-group">
            <label>채널명 <span class="required">*</span></label>
            <input v-model="formData.name" type="text" class="form-input" placeholder="예: 정문 CCTV" />
          </div>

          <div class="form-group">
            <label>소스 타입</label>
            <div class="source-toggle">
              <button type="button" :class="['toggle-btn', { active: formData.sourceType === 'rtsp' }]" @click="formData.sourceType = 'rtsp'">소스 URL</button>
              <button type="button" :class="['toggle-btn', { active: formData.sourceType === 'webcam' }]" @click="formData.sourceType = 'webcam'">웹캠</button>
            </div>
          </div>

          <div v-if="formData.sourceType === 'rtsp'" class="form-group">
            <input v-model="formData.rtspUrl" type="text" class="form-input" placeholder="rtsp://192.168.x.x:554/stream 또는 http://..." />
          </div>

          <div class="form-group">
            <label>구역</label>
            <div class="select-wrap">
              <select v-model="formData.zone" class="form-select">
                <option value="">없음</option>
                <option v-for="z in zones" :key="z" :value="z">{{ z }}</option>
              </select>
              <i class="ri-arrow-down-s-line select-arrow"></i>
            </div>
          </div>
        </div>

        <div class="modal-divider"></div>

        <div class="modal-footer">
          <button type="button" class="btn-cancel" @click="closeModal">취소</button>
          <button type="button" class="btn-save" :disabled="submitting" @click="handleSubmit">
            {{ submitting ? '저장 중...' : '저장' }}
          </button>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, computed, onMounted, onUnmounted } from 'vue'
import { useRouter } from 'vue-router'
import { useAuthStore } from '../stores/authStore.js'
import { useEventStore } from '../stores/eventStore.js'
import { useChannels } from '../composables/useChannels.js'
import { postChannel, putChannel, deleteChannel } from '../api/channels.js'
import { fetchZones } from '../api/manuals.js'

const router = useRouter()
const authStore = useAuthStore()
const { slots, addChannel, updateChannel, removeChannel } = useChannels()
const eventStore = useEventStore()

const canEdit = computed(() => authStore.user?.role === 'admin')
const activeCount = computed(() => slots.value.filter(Boolean).length)
const historyCount = computed(() => eventStore.notifHistory.length)
const panelOpen = ref(false)
const hoveredSlot = ref(-1)
const imageErrors = ref({})

const clock = ref('')
let clockTimer = null
function updateClock() { clock.value = new Date().toLocaleTimeString('ko-KR', { hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false }) }
onMounted(() => { updateClock(); clockTimer = setInterval(updateClock, 1000) })
onUnmounted(() => { if (clockTimer) clearInterval(clockTimer) })

const showModal = ref(false)
const editingChannel = ref(null)
const activeSlot = ref(0)
const error = ref('')
const submitting = ref(false)
const zones = ref([])

const formData = ref({ name: '', sourceType: 'rtsp', rtspUrl: '', zone: '' })

function openConsole() { window.open('/search', 'cctv-console', 'width=1440,height=900,left=120,top=80') }
function handleLogout() { localStorage.removeItem('auth_token'); localStorage.removeItem('auth_user'); router.push('/login') }

async function openAddModal(slot) {
  activeSlot.value = slot
  editingChannel.value = null
  formData.value = { name: '', sourceType: 'rtsp', rtspUrl: '', zone: '' }
  error.value = ''
  showModal.value = true
  zones.value = await fetchZones().catch(() => [])
}

async function openEditModal(channel) {
  activeSlot.value = channel.slot
  editingChannel.value = channel
  formData.value = {
    name: channel.name || '',
    sourceType: channel.sourceType || 'rtsp',
    rtspUrl: channel.rtspUrl || '',
    zone: channel.zone || '',
  }
  error.value = ''
  showModal.value = true
  zones.value = await fetchZones().catch(() => [])
}

function closeModal() { showModal.value = false; editingChannel.value = null; error.value = '' }

async function handleSubmit() {
  error.value = ''
  if (!formData.value.name.trim()) { error.value = '채널명을 입력하세요.'; return }
  if (formData.value.sourceType === 'rtsp' && !formData.value.rtspUrl.trim()) { error.value = '소스 URL을 입력하세요.'; return }

  submitting.value = true
  try {
    const channelName = `cam${activeSlot.value}`
    const payload = {
      slot: activeSlot.value,
      name: formData.value.name.trim(),
      channelName,
      rtspUrl: formData.value.rtspUrl.trim() || null,
      sourceType: formData.value.sourceType,
      description: '',
      options: [],
      zone: formData.value.zone || '',
    }

    if (editingChannel.value) {
      updateChannel(activeSlot.value, { ...payload })
      await putChannel(channelName, {
        name: payload.name,
        rtspUrl: payload.rtspUrl,
        zone: payload.zone,
      }).catch(console.error)
    } else {
      const res = await postChannel(payload)
      addChannel(activeSlot.value, {
        ...payload,
        ingestion_url: res?.ingestion_url || null,
        mtxPath: res?.mtxPath || null,
      })
    }
    closeModal()
  } catch (e) {
    error.value = e?.response?.data?.detail || '채널 등록에 실패했습니다.'
  } finally {
    submitting.value = false
  }
}

function handleRemove(slot) {
  if (confirm('채널을 삭제하시겠습니까?')) {
    const ch = slots.value[slot]
    removeChannel(slot)
    if (ch) deleteChannel(`cam${slot}`).catch(console.error)
  }
}

const filter = ref('all')
const unreadCount = computed(() => eventStore.notifHistory.filter(e => !e.read).length)
const warningCount = computed(() => eventStore.notifHistory.filter(e => e.severity === 'warning').length)
const dangerCount = computed(() => eventStore.notifHistory.filter(e => e.severity === 'danger').length)
const filteredEvents = computed(() => eventStore.notifHistory.filter(e => {
  if (filter.value === 'unread') return !e.read
  if (filter.value === 'warning') return e.severity === 'warning'
  if (filter.value === 'danger') return e.severity === 'danger'
  return true
}))
const events = computed(() => eventStore.notifHistory)
</script>

<style scoped>
.dashboard-root { height: 100vh; display: flex; flex-direction: column; overflow: hidden; background: #0A0D04; position: relative; font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif; }
.ambient-bg { position: fixed; inset: 0; z-index: 0; pointer-events: none; background: linear-gradient(135deg, rgba(26, 34, 9, 0.80) 0%, rgba(10, 13, 4, 0.90) 100%); }
.ambient-radial { position: fixed; inset: 0; z-index: 0; pointer-events: none; background: radial-gradient(ellipse at 20% 50%, rgba(192, 245, 61, 0.06) 0%, transparent 50%), radial-gradient(ellipse at 80% 80%, rgba(192, 245, 61, 0.04) 0%, transparent 50%); }

.dashboard-header { position: relative; z-index: 10; display: flex; align-items: center; justify-content: space-between; padding: 0 24px; height: 56px; flex-shrink: 0; background: rgba(26, 34, 9, 0.92); backdrop-filter: blur(16px); border-bottom: 1px solid rgba(192, 245, 61, 0.15); transition: background 0.3s ease, border-color 0.3s ease; }
.header-left { display: flex; align-items: center; gap: 16px; }
.logo-group { display: flex; align-items: center; gap: 10px; }
.logo-icon { width: 32px; height: 32px; border-radius: 12px; background: rgba(192, 245, 61, 0.10); border: 1px solid rgba(192, 245, 61, 0.20); display: flex; align-items: center; justify-content: center; }
.logo-icon i { color: #C0F53D; font-size: 14px; }
.logo-text { font-size: 14px; font-weight: 600; color: #FAFFF3; letter-spacing: -0.02em; }
.status-pill { display: none; align-items: center; gap: 8px; font-size: 12px; padding: 6px 12px; border-radius: 9999px; background: rgba(26, 34, 9, 0.80); border: 1px solid rgba(192, 245, 61, 0.15); }
@media (min-width: 640px) { .status-pill { display: flex; } }
.status-dot { width: 8px; height: 8px; border-radius: 50%; background: rgba(250, 255, 243, 0.30); }
.status-dot.active { background: #C0F53D; animation: pulse 2s ease-in-out infinite; }
.status-text { color: rgba(250, 255, 243, 0.50); font-weight: 500; }
.header-center { font-size: 14px; font-family: 'SF Mono', 'Fira Code', monospace; color: rgba(250, 255, 243, 0.30); letter-spacing: 0.05em; }
.header-right { display: flex; align-items: center; gap: 8px; }
.header-btn { display: flex; align-items: center; gap: 6px; padding: 8px 12px; border-radius: 9999px; font-size: 12px; color: rgba(250, 255, 243, 0.50); background: transparent; border: 1px solid transparent; cursor: pointer; transition: all 0.2s ease; }
.header-btn:hover { color: rgba(250, 255, 243, 0.85); background: rgba(192, 245, 61, 0.08); border-color: rgba(192, 245, 61, 0.15); }
.header-btn.active { color: #FAFFF3; background: rgba(192, 245, 61, 0.12); border-color: rgba(192, 245, 61, 0.20); }
.header-btn i { font-size: 14px; }
.btn-label { display: none; }
@media (min-width: 640px) { .btn-label { display: inline; } }
.notif-badge { font-size: 10px; font-weight: 600; padding: 2px 8px; border-radius: 9999px; background: rgba(239, 68, 68, 0.20); color: #fca5a5; border: 1px solid rgba(239, 68, 68, 0.30); }

@media (prefers-color-scheme: dark) {
  .dashboard-header { background: rgba(10, 13, 4, 0.92); border-bottom-color: rgba(192, 245, 61, 0.15); }
  .logo-icon { background: rgba(192, 245, 61, 0.10); border-color: rgba(192, 245, 61, 0.20); }
  .logo-text { color: #FAFFF3; }
  .status-pill { background: rgba(26, 34, 9, 0.80); border-color: rgba(192, 245, 61, 0.15); }
  .status-text { color: rgba(250, 255, 243, 0.50); }
  .header-center { color: rgba(250, 255, 243, 0.30); }
  .header-btn { color: rgba(250, 255, 243, 0.50); }
  .header-btn:hover { color: #FAFFF3; background: rgba(192, 245, 61, 0.08); border-color: rgba(192, 245, 61, 0.15); }
  .header-btn.active { color: #FAFFF3; background: rgba(192, 245, 61, 0.12); border-color: rgba(192, 245, 61, 0.20); }
  .notif-badge { background: rgba(239, 68, 68, 0.20); color: #fca5a5; border-color: rgba(239, 68, 68, 0.30); }
}

.main-body { flex: 1; min-height: 0; position: relative; padding: 12px; z-index: 10; }
@media (min-width: 768px) { .main-body { padding: 16px; } }

.channel-grid { height: 100%; display: grid; grid-template-columns: 1fr; gap: 12px; }
@media (min-width: 1024px) { .channel-grid { grid-template-columns: 1fr 1fr; gap: 16px; } }
.slot-wrapper { min-height: 0; }

.channel-card { position: relative; height: 100%; display: flex; flex-direction: column; overflow: hidden; border-radius: 24px; background: #1A2209; border: 1px solid rgba(192, 245, 61, 0.15); transition: all 0.3s ease; cursor: default; box-shadow: 0 2px 12px rgba(192, 245, 61, 0.08); }
.channel-card:hover { border-color: rgba(192, 245, 61, 0.25); box-shadow: 0 4px 20px rgba(192, 245, 61, 0.08); }
.video-area { position: relative; flex: 1; min-height: 0; overflow: hidden; border-radius: 24px; }
.video-img { width: 100%; height: 100%; object-fit: cover; object-position: center; }
.video-fallback { position: absolute; inset: 0; display: flex; flex-direction: column; align-items: center; justify-content: center; background: #1A2209; }
.fallback-icon { width: 56px; height: 56px; border-radius: 16px; background: rgba(26, 34, 9, 0.80); display: flex; align-items: center; justify-content: center; margin-bottom: 12px; }
.fallback-icon i { font-size: 24px; color: rgba(250, 255, 243, 0.30); }
.fallback-name { font-size: 14px; color: rgba(250, 255, 243, 0.65); font-weight: 500; }
.fallback-code { font-size: 12px; color: rgba(250, 255, 243, 0.30); margin-top: 4px; }
.overlay-top { position: absolute; top: 0; left: 0; right: 0; height: 96px; background: linear-gradient(to bottom, rgba(0, 0, 0, 0.40), transparent); pointer-events: none; border-radius: 24px 24px 0 0; }
.live-badge { position: absolute; top: 16px; left: 16px; display: flex; align-items: center; gap: 8px; background: rgba(0, 0, 0, 0.50); border-radius: 9999px; padding: 6px 14px; backdrop-filter: blur(12px); border: 1px solid rgba(255, 255, 255, 0.20); }
.live-dot { width: 8px; height: 8px; border-radius: 50%; background: #C0F53D; animation: pulse 2s ease-in-out infinite; }
.live-text { font-size: 11px; color: rgba(255, 255, 255, 0.95); font-family: 'SF Mono', monospace; font-weight: 500; letter-spacing: 0.05em; }
.res-badge { position: absolute; top: 16px; right: 16px; background: rgba(0, 0, 0, 0.40); border-radius: 9999px; padding: 6px 14px; backdrop-filter: blur(12px); border: 1px solid rgba(255, 255, 255, 0.20); }
.res-badge span { font-size: 11px; color: rgba(255, 255, 255, 0.80); font-family: 'SF Mono', monospace; }
.ts-badge { position: absolute; top: 16px; left: 100px; background: rgba(0, 0, 0, 0.40); border-radius: 9999px; padding: 6px 14px; backdrop-filter: blur(12px); border: 1px solid rgba(255, 255, 255, 0.20); }
.ts-badge span { font-size: 11px; color: rgba(255, 255, 255, 0.70); font-family: 'SF Mono', monospace; }
.action-buttons { position: absolute; top: 16px; right: 16px; display: flex; align-items: center; gap: 8px; }
.action-btn { width: 36px; height: 36px; border-radius: 50%; background: rgba(26, 34, 9, 0.85); backdrop-filter: blur(12px); border: 1px solid rgba(192, 245, 61, 0.20); display: flex; align-items: center; justify-content: center; color: rgba(250, 255, 243, 0.65); cursor: pointer; transition: all 0.2s ease; }
.action-btn:hover { background: #1A2209; color: #FAFFF3; box-shadow: 0 2px 8px rgba(192, 245, 61, 0.15); }
.action-btn.delete:hover { color: #ef4444; background: rgba(239, 68, 68, 0.15); border-color: rgba(239, 68, 68, 0.40); }
.action-btn i { font-size: 14px; }
.overlay-bottom { position: absolute; bottom: 0; left: 0; right: 0; height: 144px; background: linear-gradient(to top, rgba(0, 0, 0, 0.60), rgba(0, 0, 0, 0.30), transparent); pointer-events: none; border-radius: 0 0 24px 24px; }
.channel-info { position: absolute; bottom: 0; left: 0; right: 0; padding: 20px; display: flex; align-items: flex-end; justify-content: space-between; }
.info-name { font-size: 16px; font-weight: 600; color: rgba(255, 255, 255, 0.95); margin-bottom: 4px; }
.info-meta { font-size: 12px; color: rgba(255, 255, 255, 0.65); }
.status-chip { display: flex; align-items: center; gap: 6px; background: rgba(192, 245, 61, 0.12); border-radius: 9999px; padding: 6px 14px; border: 1px solid rgba(192, 245, 61, 0.25); flex-shrink: 0; }
.chip-dot { width: 6px; height: 6px; border-radius: 50%; background: #C0F53D; animation: pulse 2s ease-in-out infinite; }
.chip-text { font-size: 11px; color: #C0F53D; font-weight: 500; }

.empty-slot { height: 100%; display: flex; flex-direction: column; align-items: center; justify-content: center; border-radius: 24px; border: 1px dashed rgba(192, 245, 61, 0.20); background: rgba(26, 34, 9, 0.60); transition: all 0.3s ease; cursor: pointer; }
.empty-slot:hover { border-color: rgba(192, 245, 61, 0.35); background: rgba(192, 245, 61, 0.08); }
.empty-icon { width: 64px; height: 64px; border-radius: 16px; display: flex; align-items: center; justify-content: center; background: rgba(26, 34, 9, 0.80); border: 1px solid rgba(192, 245, 61, 0.15); transition: all 0.3s ease; }
.empty-slot:hover .empty-icon { background: rgba(192, 245, 61, 0.10); border-color: rgba(192, 245, 61, 0.25); }
.empty-icon i { font-size: 24px; color: rgba(250, 255, 243, 0.30); transition: all 0.3s ease; }
.empty-slot:hover .empty-icon i { color: #C0F53D; }
.empty-title { margin-top: 16px; font-size: 14px; font-weight: 500; color: rgba(250, 255, 243, 0.50); transition: all 0.3s ease; }
.empty-slot:hover .empty-title { color: rgba(250, 255, 243, 0.85); }
.empty-desc { margin-top: 4px; font-size: 12px; color: rgba(250, 255, 243, 0.30); transition: all 0.3s ease; }
.empty-slot:hover .empty-desc { color: rgba(250, 255, 243, 0.50); }

.event-panel { position: absolute; top: 12px; right: 12px; bottom: 12px; width: 320px; z-index: 20; background: rgba(26, 34, 9, 0.92); backdrop-filter: blur(24px); -webkit-backdrop-filter: blur(24px); border: 1px solid rgba(192, 245, 61, 0.15); border-radius: 24px; display: flex; flex-direction: column; overflow: hidden; animation: slideIn 0.4s cubic-bezier(0.16, 1, 0.3, 1) forwards; box-shadow: 0 4px 24px rgba(0, 0, 0, 0.40); }
@media (min-width: 768px) { .event-panel { top: 16px; right: 16px; bottom: 16px; } }
@keyframes slideIn { from { transform: translateX(100%); opacity: 0; } to { transform: translateX(0); opacity: 1; } }
.panel-header { display: flex; align-items: center; justify-content: space-between; padding: 16px 20px; border-bottom: 1px solid rgba(192, 245, 61, 0.15); }
.panel-title-group { display: flex; align-items: center; gap: 10px; }
.panel-icon { width: 32px; height: 32px; border-radius: 12px; background: rgba(192, 245, 61, 0.08); display: flex; align-items: center; justify-content: center; border: 1px solid rgba(192, 245, 61, 0.15); }
.panel-icon i { font-size: 14px; color: rgba(250, 255, 243, 0.50); }
.panel-title { font-size: 14px; font-weight: 600; color: #FAFFF3; }
.panel-count { font-size: 12px; color: rgba(250, 255, 243, 0.50); background: rgba(26, 34, 9, 0.80); border-radius: 9999px; padding: 2px 10px; border: 1px solid rgba(192, 245, 61, 0.15); }
.panel-close { width: 32px; height: 32px; border-radius: 50%; border: 1px solid rgba(192, 245, 61, 0.15); background: transparent; display: flex; align-items: center; justify-content: center; color: rgba(250, 255, 243, 0.50); cursor: pointer; transition: all 0.2s ease; }
.panel-close:hover { background: rgba(192, 245, 61, 0.08); color: #FAFFF3; }
.panel-close i { font-size: 14px; }
.panel-filters { display: flex; align-items: center; gap: 4px; padding: 12px; border-bottom: 1px solid rgba(192, 245, 61, 0.15); overflow-x: auto; }
.filter-tab { display: flex; align-items: center; gap: 6px; padding: 6px 10px; border-radius: 12px; font-size: 12px; color: rgba(250, 255, 243, 0.50); background: transparent; border: 1px solid transparent; cursor: pointer; transition: all 0.2s ease; white-space: nowrap; flex-shrink: 0; }
.filter-tab:hover { color: rgba(250, 255, 243, 0.85); background: rgba(192, 245, 61, 0.08); }
.filter-tab.active { color: #FAFFF3; background: rgba(192, 245, 61, 0.12); border-color: rgba(192, 245, 61, 0.20); font-weight: 500; }
.filter-count { font-size: 10px; border-radius: 9999px; padding: 1px 6px; background: rgba(26, 34, 9, 0.80); color: rgba(250, 255, 243, 0.30); }
.filter-count.active { background: rgba(192, 245, 61, 0.12); color: rgba(250, 255, 243, 0.65); }
.panel-list { flex: 1; overflow-y: auto; padding: 8px 12px; }
.panel-empty { display: flex; flex-direction: column; align-items: center; justify-content: center; padding: 64px 0; text-align: center; }
.empty-icon-box { width: 56px; height: 56px; border-radius: 16px; background: rgba(192, 245, 61, 0.08); display: flex; align-items: center; justify-content: center; margin-bottom: 16px; border: 1px solid rgba(192, 245, 61, 0.15); }
.empty-icon-box i { font-size: 20px; color: #C0F53D; }
.panel-empty .empty-title { font-size: 14px; color: rgba(250, 255, 243, 0.65); margin: 0; }
.panel-empty .empty-desc { font-size: 12px; color: rgba(250, 255, 243, 0.30); margin-top: 6px; }
.events-list { display: flex; flex-direction: column; gap: 8px; }
.event-item { padding: 14px; border-radius: 16px; transition: all 0.2s ease; display: flex; align-items: flex-start; gap: 12px; }
.event-item:hover { background: rgba(192, 245, 61, 0.08); }
.event-item.unread { background: rgba(26, 34, 9, 0.80); }
.event-item.danger { border: 1px solid rgba(239, 68, 68, 0.35); }
.event-item.warning { border: 1px solid rgba(192, 245, 61, 0.25); }
.event-item.info { border: 1px solid rgba(192, 245, 61, 0.15); }
.event-dot { width: 8px; height: 8px; border-radius: 50%; flex-shrink: 0; margin-top: 2px; }
.event-dot.danger { background: #ef4444; box-shadow: 0 0 8px rgba(239, 68, 68, 0.30); }
.event-dot.warning { background: #C0F53D; box-shadow: 0 0 8px rgba(192, 245, 61, 0.30); }
.event-dot.info { background: rgba(250, 255, 243, 0.30); }
.event-body { flex: 1; min-width: 0; }
.event-header { display: flex; align-items: center; justify-content: space-between; gap: 8px; }
.event-channel { font-size: 12px; font-weight: 500; color: #FAFFF3; margin: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.event-time { font-size: 10px; color: rgba(250, 255, 243, 0.30); flex-shrink: 0; font-family: 'SF Mono', monospace; }
.event-message { font-size: 12px; margin-top: 4px; margin-bottom: 0; }
.event-message.danger { color: #ef4444; }
.event-message.warning { color: #C0F53D; }
.event-message.info { color: rgba(250, 255, 243, 0.50); }
.panel-footer { padding: 12px 20px; border-top: 1px solid rgba(192, 245, 61, 0.15); text-align: center; }
.panel-footer p { font-size: 11px; color: rgba(250, 255, 243, 0.30); margin: 0; }

/* ── 채널 등록 모달 ── */
.modal-overlay { position: fixed; inset: 0; z-index: 50; display: flex; align-items: center; justify-content: center; background: rgba(0, 0, 0, 0.70); backdrop-filter: blur(8px); animation: fadeIn 0.2s ease-out forwards; }
@keyframes fadeIn { from { opacity: 0; } to { opacity: 1; } }
@keyframes scaleIn { from { transform: scale(0.96); opacity: 0; } to { transform: scale(1); opacity: 1; } }

.modal-card { width: 100%; max-width: 460px; margin: 0 16px; background: #1A2209; border-radius: 20px; overflow: hidden; box-shadow: 0 20px 60px rgba(0, 0, 0, 0.40); animation: scaleIn 0.25s cubic-bezier(0.16, 1, 0.3, 1) forwards; }

.modal-head { display: flex; align-items: flex-start; justify-content: space-between; padding: 24px 24px 20px; }
.modal-title { font-size: 18px; font-weight: 700; color: #FAFFF3; margin: 0 0 4px; }
.modal-cam-id { font-size: 12px; color: rgba(250, 255, 243, 0.30); margin: 0; }
.modal-close { width: 32px; height: 32px; flex-shrink: 0; border-radius: 50%; border: none; background: transparent; display: flex; align-items: center; justify-content: center; color: rgba(250, 255, 243, 0.30); cursor: pointer; transition: all 0.15s ease; }
.modal-close:hover { background: rgba(192, 245, 61, 0.08); color: rgba(250, 255, 243, 0.85); }
.modal-close i { font-size: 16px; }

.modal-body { padding: 0 24px 20px; display: flex; flex-direction: column; gap: 18px; }

.form-group { display: flex; flex-direction: column; gap: 8px; }
.form-group label { font-size: 13px; font-weight: 500; color: rgba(250, 255, 243, 0.85); }
.required { color: rgba(250, 255, 243, 0.85); }

.form-input { width: 100%; padding: 11px 14px; border: 1px solid rgba(192, 245, 61, 0.20); border-radius: 10px; font-size: 14px; color: #FAFFF3; background: rgba(26, 34, 9, 0.80); outline: none; transition: all 0.15s ease; box-sizing: border-box; }
.form-input::placeholder { color: rgba(250, 255, 243, 0.30); }
.form-input:focus { border-color: #C0F53D; background: #1A2209; box-shadow: 0 0 0 3px rgba(192, 245, 61, 0.15); }

.source-toggle { display: flex; gap: 0; border: 1px solid rgba(192, 245, 61, 0.20); border-radius: 10px; overflow: hidden; }
.toggle-btn { flex: 1; padding: 10px 16px; font-size: 14px; font-weight: 500; color: rgba(250, 255, 243, 0.50); background: rgba(26, 34, 9, 0.80); border: none; cursor: pointer; transition: all 0.15s ease; }
.toggle-btn.active { background: #C0F53D; color: #0A0D04; }
.toggle-btn:not(.active):hover { background: rgba(192, 245, 61, 0.08); color: rgba(250, 255, 243, 0.85); }

.select-wrap { position: relative; }
.form-select { width: 100%; padding: 11px 40px 11px 14px; border: 1px solid rgba(192, 245, 61, 0.20); border-radius: 10px; font-size: 14px; color: #FAFFF3; background: rgba(26, 34, 9, 0.80); appearance: none; outline: none; cursor: pointer; transition: all 0.15s ease; box-sizing: border-box; }
.form-select:focus { border-color: #C0F53D; background: #1A2209; box-shadow: 0 0 0 3px rgba(192, 245, 61, 0.15); }
.select-arrow { position: absolute; right: 12px; top: 50%; transform: translateY(-50%); font-size: 16px; color: rgba(250, 255, 243, 0.30); pointer-events: none; }

.form-error { display: flex; align-items: center; gap: 8px; background: rgba(239, 68, 68, 0.10); border: 1px solid rgba(239, 68, 68, 0.35); border-radius: 10px; padding: 10px 14px; }
.form-error i { font-size: 14px; color: #ef4444; flex-shrink: 0; }
.form-error p { font-size: 13px; color: #ef4444; margin: 0; }

.modal-divider { height: 1px; background: rgba(192, 245, 61, 0.10); margin: 0 24px; }

.modal-footer { display: flex; align-items: center; justify-content: flex-end; gap: 10px; padding: 16px 24px; }
.btn-cancel { padding: 10px 20px; border-radius: 10px; border: 1px solid rgba(192, 245, 61, 0.20); background: rgba(26, 34, 9, 0.80); font-size: 14px; font-weight: 500; color: rgba(250, 255, 243, 0.85); cursor: pointer; transition: all 0.15s ease; }
.btn-cancel:hover { background: rgba(192, 245, 61, 0.08); }
.btn-save { padding: 10px 20px; border-radius: 10px; border: none; background: #C0F53D; font-size: 14px; font-weight: 600; color: #0A0D04; cursor: pointer; transition: all 0.15s ease; }
.btn-save:hover { background: #9FD424; }
.btn-save:disabled { background: rgba(192, 245, 61, 0.35); cursor: not-allowed; }

@keyframes pulse { 0%, 100% { opacity: 1; } 50% { opacity: 0.5; } }
</style>
